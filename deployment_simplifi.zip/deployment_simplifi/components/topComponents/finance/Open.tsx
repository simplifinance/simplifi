import React from "react";
import { Common } from "./Common";

export const Open : React.FC = () => {

  return(
    <Common 
      heroTitle2="Open"
      operation='Open'
    />
  );
}