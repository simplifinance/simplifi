import React from "react";
import { Common } from "./Common";

export const Closed : React.FC = () => {

  return(
    <Common 
      heroTitle2="Closed"
      operation='Closed'
    />
  );
}